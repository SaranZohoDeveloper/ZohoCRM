function initializeWidget()
{
	/*
	 * Subscribe to the EmbeddedApp onPageLoad event before initializing the widget 
	 */
	ZOHO.embeddedApp.on("PageLoad",function(data)
	{
		
		/*
	 	 * Verify if EntityInformation is Passed 
	 	 */
		if(data && data.Entity)
		{

			ZOHO.CRM.API.getAllRecords({Entity:"analyticsreport__Crm_Analytics",sort_order:"asc",per_page:2,page:1})
			.then(function(records)
			{
				const jsonString = JSON.stringify(records["data"]);
							const dataVal = JSON.parse(jsonString);
							const id = dataVal[0].id;
							var moduleName = dataVal[0].analyticsreport__Module;
							if(moduleName == "Contacts")
							{
								reportURL = dataVal[0].analyticsreport__Src;
							}				
										
			})
			/*
		 	 * Fetch Information of Record passed in PageLoad
		 	 * and insert the response into the dom
		 	 */
			ZOHO.CRM.API.getRecord({Entity:data.Entity,RecordID:data.EntityId})
			.then(function(response)
			{
				
				const jsonString = JSON.stringify(response["data"]);
				const data = JSON.parse(jsonString);
				const recId = data[0].id;
document.getElementById("reportFrame").setAttribute("src", reportURL+recId);
			})

	

}})
	ZOHO.embeddedApp.init();
}